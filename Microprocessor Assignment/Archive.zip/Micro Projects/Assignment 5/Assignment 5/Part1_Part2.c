/*
 * Assignment 5.c
 *
 * Created: 5/13/2016 4:20:26 PM
 * Author : HosseinAgha
 */ 

#include <avr/io.h>

char buffer[10];
char coefs[10] = {-15,-29,-18,18,33,98,129,98,-33,-29,-15}
char pointer = 0;
char oneRound = 0;

char circ_buff_read(char);

int main(void)
{
	DDRB = 0x00;
	DDRC = 0xff;
	PORTC = 0x00;
	char counter = 0;
	while(true) {
		char temp = PORTB;
		char oldestIndex = circ_buff_read(temp);
		tempRes = 0;
		for (int i = oldestIndex, int j = counter; i != pointer; ++i, --j)
		{
			if(i > 9)
				i = i % 10;
			tempRes += coefs[counter]*buffer[i];
		}
		if(counter < 9)
			counter++;
		PORTC = tempRes;
	}
	return 0;
}

char circ_buff_read(char buf) {
	char oldestIndex = 0;
	if( oneRound )
		oldestIndex = (pointer + 1) % 10;
	buffer[pointer] = buf;
	pointer++;
	pointer %= 10;
	if( pointer == 0 )
		oneRound = 1;
	return oldestIndex;
}
